**To get information about applications**

This example displays information about all applications that are associated with the user's AWS account.

Command::

  aws deploy list-applications

Output::

  {
      "applications": [
          "WordPress_App",
          "MyOther_App"
      ]
  }